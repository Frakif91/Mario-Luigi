>> THANKS

Thanks for downloading MarioLuigi2! I hope you'll enjoy using it!

>> NOTES

Fun fact: MarioLuigi2 looks better in all caps.

>> PLACES

http://mrluigifreak101.deviantart.com/
http://twitter.com/LuigiFreak101

>> DISTRIBUTION

MarioLuigi2 may only be distributed on:
	> deviantART
	> DaFont
...and other places given written explicit permission by me.

>> COPYRIGHTS

MarioLuigi2 by Neil Manansala [a.k.a. LuigiFreak101 / LF]
MarioLuigi2 is Copyright (c) Neil Manansala. All rights reserved.
Characters Mario & Luigi are owned by Nintendo.

This font is NOT affiliated and/or endorsed by Nintendo and/or its affiliates.

>> LICENSING

MarioLuigi2 by Neil Manansala is licensed under a
Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
< http://creativecommons.org/licenses/by-nc-sa/3.0/ >